echo "Hello World"

mkdir document2
touch hello.txt 
